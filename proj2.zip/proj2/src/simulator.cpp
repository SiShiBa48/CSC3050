#include <cstring>
#include <stdarg.h>
#include <stdio.h>
#include <fstream>
#include <sstream>
#include <string>
#include "simulator/simulator.h"

namespace regname{
const char *REGNAME[32] = {
    "zero","ra","sp","gp","tp","t0","t1","t2","s0","s1","a0","a1","a2","a3","a4","a5","a6","a7","s2","s3","s4","s5","s6","s7","s8", "s9","s10","s11","t3","t4","t5","t6", 
};

const char *INSTNAME[]{
    "lui",  "auipc", "jal",   "jalr",  "beq",   "bne",  "blt",  "bge",  "bltu",
    "bgeu", "lb",    "lh",    "lw",    "ld",    "lbu",  "lhu",  "sb",   "sh",
    "sw",   "sd",    "addi",  "slti",  "sltiu", "xori", "ori",  "andi", "slli",
    "srli", "srai",  "add",   "sub",   "sll",   "slt",  "sltu", "xor",  "srl",
    "sra",  "or",    "and",   "ecall", "addiw", "mul",  "mulh", "div",  "rem",
    "lwu",  "slliw", "srliw", "sraiw", "addw",  "subw", "sllw", "srlw", "sraw",
};
}

using namespace regname;

// init memory, pc, register
Simulator::Simulator(MemoryManager* memory) {
  this -> memory = memory;
  this -> pc = 0;
  for (int i = 0; i < REGNUM; ++i){
    this -> reg[i] = 0;
  }
}

Simulator::~Simulator() {}

// init register, init memory (set to 0) according to stack base address and max
// size
void Simulator::init_stack(uint32_t base_addr, uint32_t max_size) {
  this->reg[REG_SP] = base_addr;
  this->stack_base = base_addr;
  this->max_stack_size = max_size;
  for (uint32_t addr = base_addr; addr > base_addr - max_size; addr--) {
    if (!this->memory->is_page_exit(addr)) {
      this->memory->add_page(addr);
    }
    this->memory->set_byte(addr, 0);
  }
}

void Simulator::simulate() {
  // initialize pipeline registers
  memset(&this->f_reg, 0, sizeof(this->f_reg));
  memset(&this->f_reg_new, 0, sizeof(this->f_reg_new));
  memset(&this->d_reg, 0, sizeof(this->d_reg));
  memset(&this->d_reg_new, 0, sizeof(this->d_reg));
  memset(&this->e_reg, 0, sizeof(this->e_reg));
  memset(&this->e_reg_new, 0, sizeof(this->e_reg_new));
  memset(&this->m_reg, 0, sizeof(this->m_reg));
  memset(&this->m_reg_new, 0, sizeof(this->m_reg_new));
  // insert Bubble to later pipeline stages when fetch the first instruction
  f_reg.bubble = true;
  d_reg.bubble = true;
  e_reg.bubble = true;
  m_reg.bubble = true;
  // main simulation loop
  while (true) {
    // set $zero to 0, some instruction might set this register to non-zero
    if (this->reg[0]!= 0){
      this->reg[0] = 0;
    }
    // check stack overflow
    if (this->max_stack_size < this->stack_base - this->reg[REG_SP]) {
      this->panic("Stack Overflow!\n");
    }
    
    this->executeWriteBack = false;
    this->executeWBReg = -1;
    this->memoryWriteBack = false;
    this->memoryWBReg = -1;

    this->fetch();
    this->decode();
    this->excecute();
    this->memory_access();
    this->write_back();

    
    // copy old register values to new register values
  }
}

// update pc and f_reg_new
void Simulator::fetch() {
  if (this->pc % 2 != 0) {
    this->panic("Illegal PC 0x%x!\n", this->pc);
  }

  uint32_t inst = this->memory->get_int(this->pc);
  uint32_t len = 4;

  this->f_reg_new.bubble = false;
  this->f_reg_new.stall = false;
  this->f_reg_new.inst = inst;
  this->f_reg_new.len = len;
  this->f_reg_new.pc = this->pc;
  this->pc = this->pc + len;
}

// decode instruction, deal with bubble and stall
// update pipeline register
void Simulator::decode() {
  if (this->f_reg.stall) {
    this->pc = this->pc - 4;
    return;
  }
  if (this->f_reg.bubble || this->f_reg.inst == 0) {
    this->d_reg_new.bubble = true;
    return;
  }
  std::string instname = "";
  std::string deststr, op1str, op2str, offsetstr;
  Instruction insttype = Instruction::UNKNOWN;
  uint32_t inst = this->f_reg.inst;
  int64_t op1 = 0, op2 = 0, offset = 0; // op1, op2 and offset are values
  uint32_t dest = 0, reg1 = -1, reg2 = -1; // reg1 and reg2 are operands

  // Reg for 32bit instructions
  if (this->f_reg.len == 4) // 32 bit instruction
  {
    uint32_t opcode = inst & 0x7F;
    uint32_t funct3 = (inst >> 12) & 0x7;
    uint32_t funct7 = (inst >> 25) & 0x7F;
    uint32_t rd = (inst >> 7) & 0x1F;
    uint32_t rs1 = (inst >> 15) & 0x1F;
    uint32_t rs2 = (inst >> 20) & 0x1F;
    int32_t imm_i = int32_t(inst) >> 20;
    int32_t imm_s = int32_t(((inst >> 7) & 0x1F) | ((inst >> 20) & 0xFE0)) << 20 >> 20;
    int32_t imm_sb = int32_t(((inst >> 7) & 0x1E) | ((inst >> 20) & 0x7E0) | ((inst << 4) & 0x800) | ((inst >> 19) & 0x1000)) << 19 >> 19;
    int32_t imm_u = int32_t(inst) >> 12;
    int32_t imm_uj = int32_t(((inst >> 21) & 0x3FF) | ((inst >> 10) & 0x400) | ((inst >> 1) & 0x7F800) | ((inst >> 12) & 0x80000)) << 12 >> 11;
    
    switch (opcode) { //all kind of opcode
    case OP_REG: //for each kinds of opcode, genrate the instruction and get the instname and insttype
      op1 = this->reg[rs1];
      op2 = this->reg[rs2];
      reg1 = rs1;
      reg2 = rs2;
      dest = rd;
      switch (funct3) {
      case 0x0: // add, mul, sub
        if (funct7 == 0x00) {
          instname = "add";
          insttype = ADD;
        } else if (funct7 == 0x20) {
          instname = "sub";
          insttype = SUB;
        } else {
          this->panic("Unknown funct7 0x%x for funct3 0x%x\n", funct7, funct3);
        }
        break;
      case 0x1: // sll, mulh
        if (funct7 == 0x00) {
          instname = "sll";
          insttype = SLL;
        } else {
          this->panic("Unknown funct7 0x%x for funct3 0x%x\n", funct7, funct3);
        }
        break;
      case 0x2: // slt
        if (funct7 == 0x00) {
          instname = "slt";
          insttype = SLT;
        } else {
          this->panic("Unknown funct7 0x%x for funct3 0x%x\n", funct7, funct3);
        }
        break;
      case 0x3: // sltu
        if (funct7 == 0x00)
        {
          instname = "sltu";
          insttype = SLTU;
        }
        else
        {
          this->panic("Unknown funct7 0x%x for funct3 0x%x\n", funct7, funct3);
        }
        break;
      case 0x4: // xor div
        if (funct7 == 0x00) {
          instname = "xor";
          insttype = XOR;
        } else {
          this->panic("Unknown funct7 0x%x for funct3 0x%x\n", funct7, funct3);
        }
        break;
      case 0x5: // srl, sra
        if (funct7 == 0x00) {
          instname = "srl";
          insttype = SRL;
        } else if (funct7 == 0x20) {
          instname = "sra";
          insttype = SRA;
        } else {
          this->panic("Unknown funct7 0x%x for funct3 0x%x\n", funct7, funct3);
        }
        break;
      case 0x6: // or, rem
        if (funct7 == 0x00) {
          instname = "or";
          insttype = OR;
        } else {
          this->panic("Unknown funct7 0x%x for funct3 0x%x\n", funct7, funct3);
        }
        break;
      case 0x7: // and
        if (funct7 == 0x00) {
          instname = "and";
          insttype = AND;
        } else {
          this->panic("Unknown funct7 0x%x for funct3 0x%x\n", funct7, funct3);
        }
        break;
      default:
        this->panic("Unknown Funct3 field %x\n", funct3);
      }
      break;

    case OP_IMM:
      op1 = this->reg[rs1];
      reg1 = rs1;
      op2 = imm_i;
      dest = rd;
      switch (funct3) {
      case 0x0:
        instname = "addi";
        insttype = ADDI;
        break;
      case 0x2:
        instname = "slti";
        insttype = SLTI;
        break;
      case 0x3:
        instname = "sltiu";
        insttype = SLTIU;
        break;
      case 0x4:
        instname = "xori";
        insttype = XORI;
        break;
      case 0x6:
        instname = "ori";
        insttype = ORI;
        break;
      case 0x7:
        instname = "andi";
        insttype = ANDI;
        break;
      case 0x1:
        instname = "slli";
        insttype = SLLI;
        op2 = op2 & 0x3F;
        break;
      case 0x5:
        if (((inst >> 26) & 0x3F) == 0x0) {
          instname = "srli";
          insttype = SRLI;
          op2 = op2 & 0x3F;
        } else if (((inst >> 26) & 0x3F) == 0x10) {
          instname = "srai";
          insttype = SRAI;
          op2 = op2 & 0x3F;
        } else {
          this->panic("Unknown funct7 0x%x for OP_IMM\n", (inst >> 26) & 0x3F);
        }
        break;
      default:
        this->panic("Unknown Funct3 field %x\n", funct3);
      }
      break;

    case OP_LUI:
      op1 = imm_u;
      op2 = 0;
      offset = imm_u;
      dest = rd;
      instname = "lui";
      insttype = LUI;
      break;

    case OP_AUIPC:
      op1 = imm_u;
      op2 = 0;
      offset = imm_u;
      dest = rd;
      instname = "auipc";
      insttype = AUIPC;
      break;

    case OP_JAL:
      op1 = imm_uj;
      op2 = 0;
      offset = imm_uj;
      dest = rd;
      instname = "jal";
      insttype = JAL;
      break;

    case OP_JALR:
      op1 = this->reg[rs1];
      reg1 = rs1;
      op2 = imm_i;
      dest = rd;
      instname = "jalr";
      insttype = JALR;
      break;

    case OP_BRANCH:
      op1 = this->reg[rs1];
      op2 = this->reg[rs2];
      reg1 = rs1;
      reg2 = rs2;
      offset = imm_sb;
      switch (funct3) {
      case 0x0:
        instname = "beq";
        insttype = BEQ;
        break;
      case 0x1:
        instname = "bne";
        insttype = BNE;
        break;
      case 0x4:
        instname = "blt";
        insttype = BLT;
        break;
      case 0x5:
        instname = "bge";
        insttype = BGE;
        break;
      case 0x6:
        instname = "bltu";
        insttype = BLTU;
        break;
      case 0x7:
        instname = "bgeu";
        insttype = BGEU;
        break;
      default:
        this->panic("Unknown funct3 0x%x at OP_BRANCH\n", funct3);
      }
      break;

    case OP_STORE:
      op1 = this->reg[rs1];
      op2 = this->reg[rs2];
      reg1 = rs1;
      reg2 = rs2;
      offset = imm_s;
      switch (funct3) {
      case 0x0:
        instname = "sb";
        insttype = SB;
        break;
      case 0x1:
        instname = "sh";
        insttype = SH;
        break;
      case 0x2:
        instname = "sw";
        insttype = SW;
        break;
      default:
        this->panic("Unknown funct3 0x%x for OP_STORE\n", funct3);
      }
      break;

    case OP_LOAD:
      op1 = this->reg[rs1];
      reg1 = rs1;
      op2 = imm_i;
      offset = imm_i;
      dest = rd;
      switch (funct3) {
      case 0x0:
        instname = "lb";
        insttype = LB;
        break;
      case 0x1:
        instname = "lh";
        insttype = LH;
        break;
      case 0x2:
        instname = "lw";
        insttype = LW;
        break;
      case 0x4:
        instname = "lbu";
        insttype = LBU;
        break;
      case 0x5:
        instname = "lhu";
        insttype = LHU;
        break;
      default:
        this->panic("Unknown funct3 0x%x for OP_LOAD\n", funct3);
      }
      break;
    
    case OP_SYSTEM:
      if (funct3 == 0x0 && funct7 == 0x000) {
        instname = "ecall";
        op1 = this->reg[REG_A0];
        op2 = this->reg[REG_A7];
        reg1 = REG_A0;
        reg2 = REG_A7;
        dest = REG_A0;
        insttype = ECALL;
      } else {
        this->panic("Unknown OP_SYSTEM inst with funct3 0x%x and funct7 0x%x\n",funct3, funct7);
      }
      break;
    default:
      this->panic("Unsupported opcode 0x%x!\n", opcode);
    }

  } else {
    this->panic("Current implementation does not support 16bit RV64C instructions!\n");
  }
  // switch (inst) {
  // case xxx:
  // xxx
  // default:
  // xxx
  // }
  if (instname != INSTNAME[insttype]) {
    this->panic("Unmatch instname %s with insttype %d\n", instname.c_str(),insttype);
  }
  this->d_reg_new.stall = false;
  this->d_reg_new.bubble = false;
  this->d_reg_new.rs1 = reg1;
  this->d_reg_new.rs2 = reg2;
  this->d_reg_new.pc = this->f_reg.pc;
  this->d_reg_new.inst = insttype;
  this->d_reg_new.dest = dest;
  this->d_reg_new.op1 = op1;
  this->d_reg_new.op2 = op2;
  this->d_reg_new.offset = offset;
}

// execute instruction, deal with bubble and stall, check hazard and forward
// data update pipeline register
void Simulator::excecute() {
if (this->d_reg.stall) {
    this->e_reg_new.bubble = true;
    return;
  }
  if (this->d_reg.bubble) {
    this->e_reg_new.bubble = true;
    return;
  }

  this->history.inst_count++;

  Instruction inst = this->d_reg.inst;
  int32_t op1 = this->d_reg.op1;
  int32_t op2 = this->d_reg.op2;
  int32_t offset = this->d_reg.offset;

  uint64_t dRegPC = this->d_reg.pc;
  bool write_reg = false;
  uint32_t dest_reg = this->d_reg.dest;
  int32_t out = 0;
  bool write_mem = false;
  bool read_unsigned_mem = false;
  bool read_signed_mem = false;
  uint32_t mem_len = 0;

  switch (inst) {
  case LUI:
    write_reg = true;
    out = offset << 12;
    break;
  case AUIPC:
    write_reg = true;
    out = dRegPC + (offset << 12);
    break;
  case JAL:
    write_reg = true;
    out = dRegPC + 4;
    dRegPC = dRegPC + op1;
    break;
  case JALR:
    write_reg = true;
    out = dRegPC + 4;
    dRegPC = (op1 + op2) & (~(uint64_t)1);
    break;
  case BEQ:
    if (op1 == op2) {
      dRegPC = dRegPC + offset;
    }
    break;
  case BNE:
    if (op1 != op2) {
      dRegPC = dRegPC + offset;
    }
    break;
  case BLT:
    if (op1 < op2) {
      dRegPC = dRegPC + offset;
    }
    break;
  case BGE:
    if (op1 >= op2) {
      dRegPC = dRegPC + offset;
    }
    break;
  case BLTU:
    if ((uint32_t)op1 < (uint32_t)op2) {
      dRegPC = dRegPC + offset;
    }
    break;
  case BGEU:
    if ((uint32_t)op1 >= (uint32_t)op2) {
      dRegPC = dRegPC + offset;
    }
    break;
  case LB:
    read_unsigned_mem = true;
    write_reg = true;
    mem_len = 1;
    out = op1 + offset;
    read_signed_mem = true;
    break;
  case LH:
    read_unsigned_mem = true;
    write_reg = true;
    mem_len = 2;
    out = op1 + offset;
    read_signed_mem = true;
    break;
  case LW:
    read_unsigned_mem = true;
    write_reg = true;
    mem_len = 4;
    out = op1 + offset;
    read_signed_mem = true;
    break;
  case LBU:
    read_unsigned_mem = true;
    write_reg = true;
    mem_len = 1;
    out = op1 + offset;
    break;
  case LHU:
    read_unsigned_mem = true;
    write_reg = true;
    mem_len = 2;
    out = op1 + offset;
    break;
  case SB:
    write_mem = true;
    mem_len = 1;
    out = op1 + offset;
    op2 = op2 & 0xFF;
    break;
  case SH:
    write_mem = true;
    mem_len = 2;
    out = op1 + offset;
    op2 = op2 & 0xFFFF;
    break;
  case SW:
    write_mem = true;
    mem_len = 4;
    out = op1 + offset;
    op2 = op2 & 0xFFFFFFFF;
    break;
  case ADDI:
  case ADD:
    write_reg = true;
    out = op1 + op2;
    break;
  case SUB:
    write_reg = true;
    out = op1 - op2;
    break;
  case SLTI:
  case SLT:
    write_reg = true;
    out = op1 < op2 ? 1 : 0;
    break;
  case SLTIU:
  case SLTU:
    write_reg = true;
    out = (uint64_t)op1 < (uint64_t)op2 ? 1 : 0;
    break;
  case XORI:
  case XOR:
    write_reg = true;
    out = op1 ^ op2;
    break;
  case ORI:
  case OR:
    write_reg = true;
    out = op1 | op2;
    break;
  case ANDI:
  case AND:
    write_reg = true;
    out = op1 & op2;
    break;
  case SLLI:
  case SLL:
    write_reg = true;
    out = op1 << op2;
    break;
  case SRLI:
  case SRL:
    write_reg = true;
    out = (uint64_t)op1 >> (uint64_t)op2;
    break;
  case SRAI:
  case SRA:
    write_reg = true;
    out = op1 >> op2;
    break;
  case ECALL:
    out = handle_system_call(op1, op2);
    write_reg = true;
    break;
  default:
    this->panic("Unknown instruction type %d\n", inst);
  }

  // switch (inst) {
  // case xxx:
  // xxx
  // default:
  // xxx
  // }
  if (isJump(inst)) {
    // Control hazard here
    this->pc = dRegPC;
    this->f_reg_new.bubble = true;
    this->d_reg_new.bubble = true;
    this->history.control_hazard_count++;
  }
  if (isReadMem(inst)) {
    if (this->d_reg_new.rs1 == dest_reg || this->d_reg_new.rs2 == dest_reg) {
      this->f_reg_new.stall = 2;
      this->d_reg_new.stall = 2;
      this->e_reg_new.bubble = true;
      this->history.cycle_count--;
      this->history.mem_hazard_count++;
    }
  }

  // Check for data hazard and forward data
  if (write_reg && dest_reg != 0 && !isReadMem(inst)) {
    if (this->d_reg_new.rs1 == dest_reg) {
      this->d_reg_new.op1 = out;
      this->executeWBReg = dest_reg;
      this->executeWriteBack = true;
      this->history.data_hazard_count++;
    }
    if (this->d_reg_new.rs2 == dest_reg) {
      this->d_reg_new.op2 = out;
      this->executeWBReg = dest_reg;
      this->executeWriteBack = true;
      this->history.data_hazard_count++;
    }
  }
  this->e_reg_new.bubble = false;
  this->e_reg_new.stall = false;
  this->e_reg_new.pc = dRegPC;
  this->e_reg_new.inst = inst;
  this->e_reg_new.op1 = op1; // for jalr
  this->e_reg_new.op2 = op2; // for store
  this->e_reg_new.write_reg = write_reg;
  this->e_reg_new.dest_reg = dest_reg;
  this->e_reg_new.out = out;
  this->e_reg_new.write_mem = write_mem;
  this->e_reg_new.read_unsigned_mem = read_unsigned_mem;
  this->e_reg_new.read_signed_mem = read_signed_mem;
  this->e_reg_new.mem_len = mem_len;
}

// memory access, deal with bubble and stall
void Simulator::memory_access() {
  if (this->e_reg.stall) {
    return;
  }
  if (this->e_reg.bubble) {
    this->m_reg_new.bubble = true;
    return;
  }

  uint32_t eRegPC = this->e_reg.pc;
  Instruction inst = this->e_reg.inst;
  bool write_reg = this->e_reg.write_reg;
  uint32_t dest_reg = this->e_reg.dest_reg;
  int32_t op1 = this->e_reg.op1; // for jalr
  int32_t op2 = this->e_reg.op2; // for store
  int32_t out = this->e_reg.out;
  bool write_mem = this->e_reg.write_mem;
  bool read_unsigned_mem = this->e_reg.read_unsigned_mem;
  bool read_signed_mem = this->e_reg.read_signed_mem;
  uint32_t mem_len = this->e_reg.mem_len;

  bool good = true;
  uint32_t cycles = 0;

  if (write_mem) {
    switch (mem_len) {
    case 1:
      good = this->memory->set_byte(out, op2, &cycles);
      break;
    case 2:
      good = this->memory->set_short(out, op2, &cycles);
      break;
    case 4:
      good = this->memory->set_int(out, op2, &cycles);
      break;
    default:
      this->panic("Unknown mem_len %d\n", mem_len);
    }
  }

  if (!good) {
    this->panic("Invalid Mem Access!\n");
  }

  if (read_unsigned_mem) {
    switch (mem_len) {
    case 1:
      if (read_signed_mem) {
        out = (int32_t)this->memory->get_byte(out, &cycles);
      } else {
        out = (uint32_t)this->memory->get_byte(out, &cycles);
      }
      break;
    case 2:
      if (read_signed_mem) {
        out = (int32_t)this->memory->get_short(out, &cycles);
      } else {
        out = (uint32_t)this->memory->get_short(out, &cycles);
      }
      break;
    case 4:
      if (read_signed_mem) {
        out = (int32_t)this->memory->get_int(out, &cycles);
      } else {
        out = (uint32_t)this->memory->get_int(out, &cycles);
      }
      break;
    default:
      this->panic("Unknown mem_len %d\n", mem_len);
    }
  }

  this->history.cycle_count += cycles;

  if (write_reg && dest_reg != 0) {
    if (this->d_reg_new.rs1 == dest_reg) {
      // Avoid overwriting recent values
      if (this->executeWriteBack == false ||
          (this->executeWriteBack && this->executeWBReg != dest_reg)) {
        this->d_reg_new.op1 = out;
        this->memoryWriteBack = true;
        this->memoryWBReg = dest_reg;
        this->history.data_hazard_count++;
      }
    }
    if (this->d_reg_new.rs2 == dest_reg) {
      // Avoid overwriting recent values
      if (this->executeWriteBack == false ||
          (this->executeWriteBack && this->executeWBReg != dest_reg)) {
        this->d_reg_new.op2 = out;
        this->memoryWriteBack = true;
        this->memoryWBReg = dest_reg;
        this->history.data_hazard_count++;
      }
    }
    // Corner case of forwarding mem load data to stalled decode reg
    if (this->d_reg.stall) {
      if (this->d_reg.rs1 == dest_reg) this->d_reg.op1 = out;
      if (this->d_reg.rs2 == dest_reg) this->d_reg.op2 = out;
      this->memoryWriteBack = true;
      this->memoryWBReg = dest_reg;
      this->history.data_hazard_count++;
    }
  }

  this->m_reg_new.bubble = false;
  this->m_reg_new.stall = false;
  this->m_reg_new.pc = eRegPC;
  this->m_reg_new.inst = inst;
  this->m_reg_new.op1 = op1;
  this->m_reg_new.op2 = op2;
  this->m_reg_new.dest_reg = dest_reg;
  this->m_reg_new.write_reg = write_reg;
  this->m_reg_new.out = out;
}

// write result to register, deal with bubble and stall
// chec k for data hazard and forward data
// update pipeline register
void Simulator::write_back() {
  if (this->m_reg.stall) {
    return;
  }
  if (this->m_reg.bubble) {
    return;
  }

  if (this->m_reg.write_reg && this->m_reg.dest_reg != 0) {
    // Check for data hazard and forward data
    if (this->d_reg_new.rs1 == this->m_reg.dest_reg) {
      // Avoid overwriting recent data
      if (!this->executeWriteBack || (this->executeWriteBack && this->executeWBReg != this->m_reg.dest_reg)) {
        if (!this->memoryWriteBack || (this->memoryWriteBack && this->memoryWBReg != this->m_reg.dest_reg)) {
          this->d_reg_new.op1 = this->m_reg.out;
          this->history.data_hazard_count++;
        }
      }
    }
    if (this->d_reg_new.rs2 == this->m_reg.dest_reg) {
      // Avoid overwriting recent data
      if (!this->executeWriteBack ||(this->executeWriteBack && this->executeWBReg != this->m_reg.dest_reg)) {
        if (!this->memoryWriteBack ||(this->memoryWriteBack && this->memoryWBReg != this->m_reg.dest_reg)) {
          this->d_reg_new.op2 = this->m_reg.out;
          this->history.data_hazard_count++;
        }
      }
    }

    // Real Write Back
    this->reg[this->m_reg.dest_reg] = this->m_reg.out;
  }

}

// handle system according to system call number in reg a7
// exit program using exit(0);
int32_t Simulator::handle_system_call(int32_t op1, int32_t op2) { 
  int32_t type = op2; // reg a7
  int32_t arg1 = op1; // reg a0
  switch (type) {
  case 0: { // print string
    uint32_t addr = arg1;
    char ch = this->memory->get_byte(addr);
    while (ch != '\0') {
      printf("%c", ch);
      ch = this->memory->get_byte(++addr);
    }
    break;
  }
  case 1: // print char
    printf("%c", (char)arg1);
    break;
  case 2: // print num
    printf("%d", (int32_t)arg1);
    break;
  case 3: // exit
    printf("Program exit from an exit() system call\n");
    this->print_history();
    exit(0);
  case 4: // read char
    scanf(" %c", (char*)&op1);
    break;
  case 5: // read num
    scanf(" %lld", &op1);
    break;
  default:
    this->panic("Unknown syscall type %d\n", type);
  }
  return op1; 
}

void Simulator::print_history(){
  printf("------------ STATISTICS -----------\n");
  printf("Number of Instructions: %u\n", this->history.inst_count);
  printf("Number of Cycles: %u\n", this->history.cycle_count);
  printf("Avg Cycles per Instrcution: %.4f\n",
         (float)this->history.cycle_count / this->history.inst_count);
  printf("Number of Control Hazards: %u\n",
         this->history.control_hazard_count);
  printf("Number of Data Hazards: %u\n", this->history.data_hazard_count);
  printf("Number of Memory Hazards: %u\n",
         this->history.mem_hazard_count);
  printf("-----------------------------------\n");
}

void Simulator::panic(const char *format, ...) {
  char buf[BUFSIZ];
  va_list args;
  va_start(args, format);
  vsprintf(buf, format, args);
  fprintf(stderr, "%s", buf);
  va_end(args);
  this->print_history();
  exit(-1);
}