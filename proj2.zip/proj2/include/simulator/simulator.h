#ifndef SIMULATOR_H
#define SIMULATOR_H

#include "simulator/memory_manager.h"
#include <cstdint>

namespace regname{
const int REGNUM = 32;
extern const char *REGNAME[32];
extern const char *INSTNAME[];
enum Instruction {
  LUI = 0,
  AUIPC = 1,
  JAL = 2,
  JALR = 3,
  BEQ = 4,
  BNE = 5,
  BLT = 6,
  BGE = 7,
  BLTU = 8,
  BGEU = 9,
  LB = 10,
  LH = 11,
  LW = 12,
  LBU = 13,
  LHU = 14,
  SB = 15,
  SH = 16,
  SW = 17,
  ADDI = 18,
  SLTI = 19,
  SLTIU = 20,
  XORI = 21,
  ORI = 22,
  ANDI = 23,
  SLLI = 24,
  SRLI = 25,
  SRAI = 26,
  ADD = 27,
  SUB = 28,
  SLL = 29,
  SLT = 30,
  SLTU = 31,
  XOR = 32,
  SRL = 33,
  SRA = 34,
  OR = 35,
  AND = 36,
  ECALL = 37,
  UNKNOWN = -1,
};

enum Reg {
  REG_ZERO = 0,
  REG_RA = 1,
  REG_SP = 2,
  REG_GP = 3,
  REG_TP = 4,
  REG_T0 = 5,
  REG_T1 = 6,
  REG_T2 = 7,
  REG_S0 = 8,
  REG_S1 = 9,
  REG_A0 = 10,
  REG_A1 = 11,
  REG_A2 = 12,
  REG_A3 = 13,
  REG_A4 = 14,
  REG_A5 = 15,
  REG_A6 = 16,
  REG_A7 = 17,
  REG_S2 = 18,
  REG_S3 = 19,
  REG_S4 = 20,
  REG_S5 = 21,
  REG_S6 = 22,
  REG_S7 = 23,
  REG_S8 = 24,
  REG_S9 = 25,
  REG_S10 = 26,
  REG_S11 = 27,
  REG_T3 = 28,
  REG_T4 = 29,
  REG_T5 = 30,
  REG_T6 = 31,
};

// opcode field
const int OP_REG = 0x33;
const int OP_IMM = 0x13;
const int OP_LUI = 0x37;
const int OP_BRANCH = 0x63;
const int OP_STORE = 0x23;
const int OP_LOAD = 0x03;
const int OP_SYSTEM = 0x73;
const int OP_AUIPC = 0x17;
const int OP_JAL = 0x6F;
const int OP_JALR = 0x67;

inline bool isJump(Instruction inst) {
  if (inst == JAL || inst == JALR) {
    return true;
  }
  return false;
}

inline bool isReadMem(Instruction inst) {
  if (inst == LB || inst == LH || inst == LW || inst == LBU || inst == LHU) {
    return true;
  }
  return false;
}
}

class Simulator {
public:
  uint32_t pc;
  uint32_t reg[REGNUM];
  uint32_t stack_base;
  uint32_t max_stack_size;
  MemoryManager* memory;

  Simulator(MemoryManager* memory);
  ~Simulator();

  void init_stack(uint32_t base_addr, uint32_t max_size);
  void simulate();

private:
  // can change according your need
  struct FetchRegister {
    bool bubble;//bubble to stop the new fetch
    uint32_t stall;//

    uint32_t pc;//the position of pc
    uint32_t inst;//the inst of command?
    uint32_t len;//len always = 4
  } f_reg, f_reg_new;

  // can change according your need
  struct DecodeRegister {
    bool bubble;
    uint32_t stall;
    uint32_t rs1, rs2;

    uint32_t pc;
    Instruction inst;
    int32_t op1;
    int32_t op2;
    uint32_t dest;
    int32_t offset;
  } d_reg, d_reg_new;

  // can change according your need
  struct ExecuteRegister {
    bool bubble;
    uint32_t stall;

    uint32_t pc;
    Instruction inst;
    int32_t op1;
    int32_t op2;
    bool write_reg;
    uint32_t dest_reg;
    // output of execute stage
    int32_t out;
    bool write_mem;
    bool read_unsigned_mem;
    bool read_signed_mem;
    uint32_t mem_len;
  } e_reg, e_reg_new;

  // can change according your need
  struct MemoryRegister {
    bool bubble;
    uint32_t stall;

    uint32_t pc;
    Instruction inst;
    int32_t op1;
    int32_t op2;
    int32_t out;
    bool write_reg;
    uint32_t dest_reg;
    bool wriet_mem;
    bool read_unsigned_mem;
    bool read_signed_mem;
    uint32_t mem_len;
  } m_reg, m_reg_new;

  bool executeWriteBack;
  uint32_t executeWBReg;
  bool memoryWriteBack;
  uint32_t memoryWBReg;

  // can change according your need
  struct History {
    uint32_t inst_count;
    uint32_t cycle_count;
    uint32_t stall_cycle_count;

    uint32_t data_hazard_count;
    uint32_t control_hazard_count;
    uint32_t mem_hazard_count;
  } history;

  void fetch();
  void decode();
  void excecute();
  void memory_access();
  void write_back();

  int32_t handle_system_call(int32_t op1, int32_t op2);
  void print_history();
  void panic(const char *format, ...);
};

#endif
